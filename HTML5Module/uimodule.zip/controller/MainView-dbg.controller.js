sap.ui.define(["com/myorg/ui5serverless/controller/BaseController"], function (Controller) {
    "use strict";

    return Controller.extend("com.myorg.ui5serverless.controller.MainView", {});
});
